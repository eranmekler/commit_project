import json
import base64
import urllib.request
import urllib.parse
import os  # Import the os module

def lambda_handler(event, context):
    # Check if 'code' exists in queryStringParameters
    if not event.get('queryStringParameters') or 'code' not in event['queryStringParameters']:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': "Required 'code' parameter."})
        }

    auth_code = event['queryStringParameters']['code']

    # Fetch environment variables
    token_url = os.environ.get('TOKEN_URL')
    client_id = os.environ.get('CLIENT_ID')
    client_secret = os.environ.get('CLIENT_SECRET')
    redirect_uri = os.environ.get('REDIRECT_URI')
    api_url = os.environ.get('API_URL')

    if not all([token_url, client_id, client_secret, redirect_uri, api_url]):
        return {
            'statusCode': 500,
            'body': json.dumps({'error': "Some required environment variables are missing."})
        }

    # Create the Basic Authorization header
    auth_header = base64.b64encode(f"{client_id}:{client_secret}".encode('utf-8')).decode('utf-8')
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': f'Basic {auth_header}'
    }

    # Data for the token request
    data = {
        'grant_type': 'authorization_code',
        'client_id': client_id,
        'code': auth_code,
        'redirect_uri': redirect_uri
    }

    # Make the POST request to exchange auth code for access token
    data_encoded = urllib.parse.urlencode(data).encode('utf-8')
    request = urllib.request.Request(token_url, data=data_encoded, headers=headers)
    try:
        with urllib.request.urlopen(request) as response:
            response_data = json.loads(response.read())
            token = response_data['id_token']
    except urllib.error.HTTPError as e:
        return {
            'statusCode': e.code,
            'body': json.dumps({'error': 'Failed to get token'})
        }

    # Use the access token to make the authenticated request to the API Gateway
    headers = {'Authorization': f'Bearer {token}'}
    request = urllib.request.Request(api_url, headers=headers)
    try:
        with urllib.request.urlopen(request) as response:
            return {
                'statusCode': 200,
                'body': json.loads(response.read())
            }
    except urllib.error.HTTPError as e:
        return {
            'statusCode': e.code,
            'body': json.dumps({'error': 'API request failed'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal server error'})
        }
