import json
import boto3
import logging
import random
import os  # Added the os module to access environment variables
from botocore.exceptions import BotoCoreError, ClientError
import datetime
import jwt

# Initialize logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
ssm = boto3.client('ssm')
s3 = boto3.client('s3')

# Fetch environment variables
DYNAMO_TABLE_NAME = os.environ['DYNAMO_TABLE_NAME']
S3_BUCKET_NAME = os.environ['S3_BUCKET_NAME']

now = datetime.datetime.now()

# Add 3 hours to it
three_hours_later = now + datetime.timedelta(hours=3)

# Print the result in the specified format
formatted_time = three_hours_later.strftime('%Y-%m-%d %H:%M')

def lambda_handler(event, context):
    try:
        # Retrieve the token from the header
        token = event['headers']['Authorization'].split(" ")[1]  # get token from 'Bearer <token>'
        
        # Get user from Cognito
        decoded_token = jwt.decode(token, algorithms=[], verify=False, options={'verify_signature': False})
        user_name = decoded_token.get('cognito:username', 'No username found')
        table = dynamodb.Table(DYNAMO_TABLE_NAME)
        
        # Insert an item to DynamoDB table
        table.put_item(Item={'username': user_name, 'timestamp': f'{formatted_time} UTC +03:00'})

        logger.info(f'Successfully inserted item for user: {user_name}')

        # Get a random SSM Parameter
        response = ssm.describe_parameters()
        parameters = response['Parameters']
        random_parameter = random.choice(parameters)
        parameter_name = random_parameter['Name']
        value = ssm.get_parameter(Name=parameter_name, WithDecryption=True)['Parameter']['Value']

        logger.info(f'Retrieved SSM parameter: {parameter_name} with value: {value}')

        # Modify the response body
        response_body = f"{value} {user_name}"
        
        # Add to s3 bucket
        file_name = f'{user_name}'
        current_date = f'{formatted_time} UTC +03:00'
        content = f'Current date and time:, {current_date}.'
        s3.put_object(Body=content, Bucket=S3_BUCKET_NAME, Key=file_name)

        return build_http_response(200, response_body)

    except (BotoCoreError, ClientError) as error:
        logger.error("Error processing request: %s", str(error))
        return build_http_response(500, "An error occurred while processing your request")

def build_http_response(status_code, body):
    return {
        "statusCode": status_code,
        "body": json.dumps(body),
        "headers": {
            "Content-Type": "application/json"
        } 
    }
